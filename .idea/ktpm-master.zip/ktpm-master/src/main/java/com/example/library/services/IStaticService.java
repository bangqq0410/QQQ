package com.example.library.services;

public interface IStaticService {
    int getTotalBook();
    int getTotalReader();
    int getTotalBorrow();
    int getTotalLate();
    int getTotalReturn();
}
