package com.example.library;

public class Main {
    public static void main(String[] args) {
        App.main(args);
    }
}
